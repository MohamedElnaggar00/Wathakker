# Wathakker 3.0.1 label hotfix

Overlay on the 3.0.0 recovered build. Application and launcher use @string/app_name; app_name is وذكر. Original package com.wathakker.app; versionCode7/versionName3.0.1. debuggable=false. Use apktool build -f so changed manifest version metadata is not hidden by cached compiled resources. Same Morphe signing certificate as 3.0.0, so no uninstall is needed when updating that new installation.

The 3.0.1 unsigned input and signing workflow are in main. Signed APK SHA256: f5da46e669b5ab288c4814074b4bbe5f4223f0624e6771e4f207ecb20e6935ac.

Private/personal use only. Expo font license remains unverified. No keystore/private key/password is in this patch.
