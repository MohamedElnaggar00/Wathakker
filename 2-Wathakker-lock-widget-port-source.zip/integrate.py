from pathlib import Path
import xml.etree.ElementTree as E,shutil
root=Path('/home/sandbox/recovery/patched');base=Path('/home/sandbox/recovery/decoded');src=Path('/home/sandbox/Prayer-Sam-Widgets/app/src/main')
a='http://schemas.android.com/apk/res/android'; app='http://schemas.android.com/apk/res-auto';E.register_namespace('android',a);E.register_namespace('app',app)
# Preserve all twelve original home widget providers for the actual merge, add six new lock-only providers.
for p in (base/'res/xml').glob('widget_*_info.xml'):shutil.copy(p,root/'res/xml'/p.name)
(root/'assets/lockfonts').mkdir(parents=True,exist_ok=True)
for p in (src/'res/font').glob('*.ttf'):shutil.copy(p,root/'assets/lockfonts'/p.name)
shutil.copy(src/'assets/fonts/OFL.txt',root/'assets/lockfonts/OFL.txt')
layout='''<?xml version="1.0" encoding="utf-8"?><FrameLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><ImageView android:id="@+id/lock_widget_art" android:layout_width="match_parent" android:layout_height="match_parent" android:scaleType="fitCenter" android:contentDescription="@string/lock_widget_description" /></FrameLayout>'''
(root/'res/layout/lock_widget_image.xml').write_text(layout)
strings=E.parse(root/'res/values/strings.xml'); E.SubElement(strings.getroot(),'string',name='lock_widget_description').text='ويدجت شاشة القفل';strings.write(root/'res/values/strings.xml',encoding='utf-8',xml_declaration=True)
m=E.parse(base/'AndroidManifest.xml');manifest=m.getroot();application=manifest.find('application')
old='com.wathakker.app';new='com.wathakker.locktest';manifest.set('package',new)
for el in manifest.iter():
 for k,v in list(el.attrib.items()):
  if old in v:el.set(k,v.replace(old,new))
application.set('{'+a+'}label','وَذكِّر - اختبار القفل')
# Label launcher explicitly too.
for el in application.findall('activity'):
 if el.get('{'+a+'}name')=='com.example.MainActivity':el.set('{'+a+'}label','وَذكِّر - اختبار القفل')
spec=[('Day','day_name','اليوم'),('Prayers','prayer_times','مواقيت الصلاة'),('Tasbih','tasbih','التسبيح'),('Hijri','hijri_date','التاريخ الهجري'),('Gregorian','gregorian_date','التاريخ الميلادي'),('Next','next_prayer','الصلاة القادمة')]
for typ,name,label in spec:
 tree=E.parse(src/f'res/xml/widget_{name}_info.xml');r=tree.getroot()
 r.set('{'+a+'}description','@string/lock_widget_description')
 for k,v in list(r.attrib.items()):
  if 'Layout' in k or 'layout' in k:r.set(k,'@layout/lock_widget_image')
 tree.write(root/f'res/xml/lock_{name}_info.xml',encoding='utf-8',xml_declaration=True)
 rec=E.SubElement(application,'receiver',{'{'+a+'}name':'com.example.lockwidgets.LockWidgets$'+typ,'{'+a+'}label':label+' - قفل','{'+a+'}exported':'true'})
 filt=E.SubElement(rec,'intent-filter');E.SubElement(filt,'action',{'{'+a+'}name':'android.appwidget.action.APPWIDGET_UPDATE'})
 E.SubElement(rec,'meta-data',{'{'+a+'}name':'android.appwidget.provider','{'+a+'}resource':'@xml/lock_'+name+'_info'})
rec=E.SubElement(application,'receiver',{'{'+a+'}name':'com.example.lockwidgets.LockWidgets','{'+a+'}exported':'false'})
filt=E.SubElement(rec,'intent-filter')
for action in ['BOOT_COMPLETED','TIME_SET','TIMEZONE_CHANGED','DATE_CHANGED','MY_PACKAGE_REPLACED']:E.SubElement(filt,'action',{'{'+a+'}name':'android.intent.action.'+action})
m.write(root/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
print('Added six native lock widgets, retained twelve originals; isolated test package')
