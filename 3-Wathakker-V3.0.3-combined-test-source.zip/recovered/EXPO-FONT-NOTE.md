# Expo Arabic font scope

The user requested the original Athkar font for a private personal-use test app and explicitly said the app will not be published (11 October 2026). Fonts were extracted from the supplied Athkar reference APK. Expo Arabic Medium and SemiBold retain their original metadata: Copyright 2015 Pascal Zoghbi, all rights reserved.

No transferable app-embedding license has been established. Personal-use approval does not establish a license. Do not publish the app or redistribute these font files publicly. Review licensing before any publication or wider sharing. Keep this warning with private project backups.

Original prayer-progress preview: Medium for labels, dates, prayer names and countdown; SemiBold for times.

Sources: https://www.29lt.com/custom-type/ and https://www.29lt.com/info/fonts-licensing/
