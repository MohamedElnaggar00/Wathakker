from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
root=Path('/home/sandbox/recovery/patched/res');assets=Path('/home/sandbox/recovery/patched/assets');S=4
book=str(assets/'lockpersonal/expoarabic_book.ttf');bold=str(assets/'lockpersonal/expoarabic_bold.ttf');amiri=str(assets/'lockfonts/amiri_bold.ttf')
def text(im,t,x,y,size=16,font=bold,lang='ar',maxw=110):
 d=ImageDraw.Draw(im);f=ImageFont.truetype(font,round(size*S));kw={'direction':'rtl' if lang=='ar' else 'ltr','language':lang}
 while d.textlength(t,font=f,**kw)>maxw*S and f.size>12:f=ImageFont.truetype(font,f.size-1)
 d.text((x*S,y*S),t,font=f,fill='white',anchor='mm',**kw)
types={'day_name':'Day','prayer_times':'Prayers','tasbih':'Tasbih','hijri_date':'Hijri','gregorian_date':'Gregorian','next_prayer':'Next','prayer_bar':'Bar'}
imgs=[]
for key,t in types.items():
 for tiny in [False,True] if t in ['Hijri','Gregorian','Next'] else [False]:
  w=54 if tiny else 123;name='lock_preview_'+key+('_tiny' if tiny else '')
  for lang in ['ar','en']:
   ar=lang=='ar';im=Image.new('RGBA',(w*S,54*S));d=ImageDraw.Draw(im)
   if t=='Day' and ar:
    art=Image.open(assets/'lockpersonal/day_6.png').convert('RGBA');art.thumbnail((99*S,34*S));white=Image.new('RGBA',art.size,'white');white.putalpha(art.getchannel('A'));im.alpha_composite(white,((w*S-art.width)//2,(54*S-art.height)//2))
   elif t=='Day':text(im,'Friday',w/2,27,29,amiri,lang)
   elif t=='Gregorian':
    text(im,'١١' if ar else '11',w/2,18,18,lang=lang) if tiny else text(im,'١١ أكتوبر' if ar else '11 October',w/2,18,18,lang=lang)
    text(im,('١٠/٢٠٢٦' if ar else '10/2026') if tiny else ('٢٠٢٦' if ar else '2026'),w/2,38,9 if tiny else 16,lang=lang)
   elif t=='Hijri':
    text(im,('٣٠' if ar else '30') if tiny else ('٣٠ ربيع الآخر' if ar else "30 Rabi' al-Thani"),w/2,18,18 if tiny else 17,lang=lang)
    text(im,('ربيع الآخر' if ar else "Rabi' II") if tiny else ('١٤٤٨' if ar else '1448'),w/2,38,9 if tiny else 16,lang=lang)
   elif t=='Tasbih':text(im,'سُبْحَانَ اللَّه' if ar else 'SubhanAllah',w/2,19,17,amiri,lang);text(im,'٠ / ٣٣' if ar else '0 / 33',w/2,39,13,book,lang)
   elif t=='Prayers':
    names=['الفجر','الظهر','العصر','المغرب','العشاء'] if ar else ['Fajr','Dhuhr','Asr','Maghrib','Isha'];ts=['٥:٢٨','١٢:١٧','٣:٣٠','٥:٤٠','٧:٠٠'] if ar else ['5:28','12:17','3:30','5:40','7:00']
    for j in range(5):
     x=w-12-19.8*(j+.5) if ar else 12+19.8*(j+.5);text(im,names[j],x,20,7,book,lang,18);text(im,ts[j],x,34,8,bold,lang,18)
   elif t=='Bar':
    text(im,'الظهر' if ar else 'Dhuhr',w/2,13,13,bold,lang);d.rounded_rectangle((12*S,26*S,(w-12)*S,30*S),radius=2*S,fill='#666666');d.rounded_rectangle(((w-12-45)*S if ar else 12*S,26*S,(w-12)*S if ar else 57*S,30*S),radius=2*S,fill='white');text(im,'١٢:١٧' if ar else '12:17',w/2,42,12,book,lang)
   elif t=='Next':
    for t2,y,sz in ([('الظهر' if ar else 'Dhuhr',12,12),('١٢:١٧' if ar else '12:17',27,11),('٥ س ٤٣ د' if ar else '5h 43m',42,9)] if tiny else [('الظهر ١٢:١٧' if ar else 'Dhuhr 12:17',18,13),('باقي على الظهر ٥ س ٤٣ د' if ar else '5h 43m to Dhuhr',37,9)]):text(im,t2,w/2,y,sz,book if sz==9 else bold,lang)
   for bucket,mul in [('mdpi',1),('hdpi',1.5),('xhdpi',2),('xxhdpi',3),('xxxhdpi',4)]:
    dest=root/('drawable-'+('en-' if lang=='en' else '')+bucket);dest.mkdir(exist_ok=True);im.resize((round(w*mul),round(54*mul)),Image.Resampling.LANCZOS).save(dest/(name+'.png'))
   if ar:
    bg=Image.new('RGBA',im.size);ImageDraw.Draw(bg).rounded_rectangle((0,0,w*S-1,54*S-1),radius=24*S,fill='#343636');bg.alpha_composite(im);imgs.append((t+(' tiny' if tiny else ''),bg))
c=Image.new('RGB',(740,len(imgs)*240),'#1b1e1e');d=ImageDraw.Draw(c)
for j,(label,im) in enumerate(imgs):c.paste(im,(30,j*240+15),im);d.text((540,j*240+90),label,fill='white')
c.save('/downloads/r10-preview-check.png')
