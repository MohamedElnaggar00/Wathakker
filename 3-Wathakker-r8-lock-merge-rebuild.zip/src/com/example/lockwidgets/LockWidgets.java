package com.example.lockwidgets;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.graphics.*;
import android.icu.util.IslamicCalendar;
import android.os.Bundle;
import android.text.*;
import android.widget.RemoteViews;
import java.lang.reflect.*;
import java.text.*;
import java.util.*;

/** Native port of Prayer-Sam-Widgets artwork and interactions into the recovered Wathakker app. */
public class LockWidgets extends AppWidgetProvider {
    public static class Day extends LockWidgets {}
    public static class Prayers extends LockWidgets {}
    public static class Tasbih extends LockWidgets {}
    public static class Hijri extends LockWidgets {}
    public static class Gregorian extends LockWidgets {}
    public static class Next extends LockWidgets {}
    private static final Class<?>[] TYPES = {Day.class,Prayers.class,Tasbih.class,Hijri.class,Gregorian.class,Next.class};
    private static String action(Context c,String suffix){return c.getPackageName()+".lockwidgets."+suffix;}
    private static int res(Context c,String type,String name){return c.getResources().getIdentifier(name,type,c.getPackageName());}
    private static boolean arabic(Context c){return c.getResources().getConfiguration().getLocales().get(0).getLanguage().equals("ar");}
    private static Locale locale(Context c){return arabic(c)?new Locale("ar"):Locale.ENGLISH;}
    private static PendingIntent pulse(Context c){return PendingIntent.getBroadcast(c,700001,new Intent(c,LockWidgets.class).setAction(action(c,"TICK")),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private static boolean active(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);for(Class<?> t:TYPES)if(m.getAppWidgetIds(new ComponentName(c,t)).length>0)return true;return false;}
    private static void schedule(Context c){AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(active(c))a.setInexactRepeating(AlarmManager.RTC,System.currentTimeMillis()+60000,60000,pulse(c));else a.cancel(pulse(c));}
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id,getClass());schedule(c);}
    @Override public void onEnabled(Context c){schedule(c);}
    @Override public void onDisabled(Context c){schedule(c);}
    @Override public void onDeleted(Context c,int[] ids){for(int id:ids)c.getSharedPreferences("lock_tasbih",0).edit().remove("count_"+id).apply();schedule(c);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){update(c,m,id,getClass());}
    @Override public void onReceive(Context c,Intent in){
        String a=in.getAction();
        if(action(c,"TAP").equals(a)){
            int id=in.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);
            AppWidgetProviderInfo info=AppWidgetManager.getInstance(c).getAppWidgetInfo(id);
            if(info!=null&&info.provider.equals(new ComponentName(c,Tasbih.class))){SharedPreferences p=c.getSharedPreferences("lock_tasbih",0);String key="count_"+id;p.edit().putInt(key,p.getInt(key,0)+1).apply();update(c,AppWidgetManager.getInstance(c),id,Tasbih.class);}return;
        }
        if(action(c,"TICK").equals(a)||Intent.ACTION_BOOT_COMPLETED.equals(a)||Intent.ACTION_TIME_CHANGED.equals(a)||Intent.ACTION_TIMEZONE_CHANGED.equals(a)||Intent.ACTION_DATE_CHANGED.equals(a)||Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)){
            updateAll(c);schedule(c);return;
        }
        super.onReceive(c,in);
    }
    public static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);for(Class<?> t:TYPES)for(int id:m.getAppWidgetIds(new ComponentName(c,t)))update(c,m,id,t);}
    private static void update(Context c,AppWidgetManager m,int id,Class<?> type){
        RemoteViews v=new RemoteViews(c.getPackageName(),res(c,"layout","lock_widget_image"));
        Bitmap bmp=render(c,type,id);
        v.setImageViewBitmap(res(c,"id","lock_widget_art"),bmp);
        if(type==Tasbih.class){Intent tap=new Intent(c,LockWidgets.class).setAction(action(c,"TAP")).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);v.setOnClickPendingIntent(res(c,"id","lock_widget_art"),PendingIntent.getBroadcast(c,id,tap,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));}
        else {Intent open=new Intent().setClassName(c.getPackageName(),"com.example.MainActivity");v.setOnClickPendingIntent(res(c,"id","lock_widget_art"),PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));}
        m.updateAppWidget(id,v);
    }
    /** Call r7's own calculator/preferences so all widgets agree with its prayer screen. */
    private static long[] times(Context c,Calendar day)throws Exception{
        Class<?> p=Class.forName("com.example.fajr.data.FajrPreferences");Object prefs=p.getConstructor(Context.class).newInstance(c);
        double lat=(Double)p.getMethod("getLatitude").invoke(prefs),lng=(Double)p.getMethod("getLongitude").invoke(prefs);
        int method=(Integer)p.getMethod("getCalculationMethodId").invoke(prefs);
        Class<?> meth=Class.forName("com.example.fajr.calculation.CalculationMethod");Object companion=meth.getField("Companion").get(null);Object choice=companion.getClass().getMethod("fromId",int.class).invoke(companion,method);
        Class<?> calc=Class.forName("com.example.fajr.calculation.PrayerTimesCalculator");Object result=calc.getMethod("calculateAll",Calendar.class,double.class,double.class,meth).invoke(calc.getField("INSTANCE").get(null),day,lat,lng,choice);
        String[] getters={"getFajr","getSunrise","getDhuhr","getAsr","getMaghrib","getIsha"};long[] out=new long[6];for(int i=0;i<6;i++)out[i]=(Long)result.getClass().getMethod(getters[i]).invoke(result);return out;
    }
    private static String time(long value,Locale l){return new SimpleDateFormat("h:mm a",l).format(new Date(value));}
    private static String number(long n,Locale l){NumberFormat f=NumberFormat.getIntegerInstance(l);f.setGroupingUsed(false);return f.format(n);}
    private static Typeface font(Context c,String file){return Typeface.createFromAsset(c.getAssets(),"lockfonts/"+file+".ttf");}
    private static TextPaint paint(Typeface font,float size,float d,int color){TextPaint p=new TextPaint(Paint.ANTI_ALIAS_FLAG);p.setTypeface(font);p.setTextSize(size*d);p.setColor(color);p.setShadowLayer(3*d,0,d,0x66000000);return p;}
    private static void lines(Canvas canvas,int w,int h,float d,String[] text,float[] sizes,Typeface[] fonts){
        StaticLayout[] ls=new StaticLayout[text.length];float total=0;
        for(int i=0;i<text.length;i++){TextPaint lp=paint(fonts[i],sizes[i],d,i==0?Color.WHITE:0xE6FFFFFF);float measured=lp.measureText(text[i]);if(measured>w-4*d)lp.setTextSize(lp.getTextSize()*(w-4*d)/measured);ls[i]=StaticLayout.Builder.obtain(text[i],0,text[i].length(),lp,w).setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build();total+=ls[i].getHeight();}
        total+=(text.length-1)*2*d;float y=Math.max(0,(h-total)/2);
        for(StaticLayout l:ls){canvas.save();canvas.translate(0,y);l.draw(canvas);canvas.restore();y+=l.getHeight()+2*d;}
    }
    public static Bitmap render(Context c,Class<?> type,int id){
        float d=c.getResources().getDisplayMetrics().density;int wd=type==Prayers.class?140:type==Next.class?150:123,hd=type==Prayers.class?150:type==Next.class?74:54;
        Bitmap bmp=Bitmap.createBitmap((int)(wd*d),(int)(hd*d),Bitmap.Config.ARGB_8888);Canvas cv=new Canvas(bmp);int w=bmp.getWidth(),h=bmp.getHeight();Locale l=locale(c);boolean ar=arabic(c);
        Typeface amiri=font(c,"amiri_bold"),medium=font(c,"tajawal_medium"),bold=font(c,"tajawal_bold");
        if(type==Day.class){lines(cv,w,h,d,new String[]{new SimpleDateFormat("EEEE",l).format(new Date())},new float[]{30},new Typeface[]{amiri});}
        else if(type==Gregorian.class){lines(cv,w,h,d,new String[]{new SimpleDateFormat("EEEE",l).format(new Date()),new SimpleDateFormat("d MMM yyyy",l).format(new Date())},new float[]{17,14},new Typeface[]{bold,medium});}
        else if(type==Hijri.class){IslamicCalendar cal=new IslamicCalendar();cal.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);cal.setTimeInMillis(System.currentTimeMillis());String[] months=ar?new String[]{"محرم","صفر","ربيع الأول","ربيع الآخر","جمادى الأولى","جمادى الآخرة","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة"}:new String[]{"Muharram","Safar","Rabi' al-Awwal","Rabi' al-Thani","Jumada al-Ula","Jumada al-Akhirah","Rajab","Sha'ban","Ramadan","Shawwal","Dhul-Qa'dah","Dhul-Hijjah"};lines(cv,w,h,d,new String[]{months[cal.get(Calendar.MONTH)],number(cal.get(Calendar.DAY_OF_MONTH),l)+" · "+number(cal.get(Calendar.YEAR),l)+(ar?" هـ":" AH")},new float[]{24,13},new Typeface[]{amiri,medium});}
        else if(type==Tasbih.class){int n=c.getSharedPreferences("lock_tasbih",0).getInt("count_"+id,0);String[] dhikr=ar?new String[]{"سبحان الله","الحمد لله","الله أكبر"}:new String[]{"SubhanAllah","Alhamdulillah","Allahu Akbar"};lines(cv,w,h,d,new String[]{dhikr[(n/33)%3],number(n%33,l)+" / "+number(33,l)},new float[]{17,22},new Typeface[]{bold,medium});}
        else {
            try {Calendar today=Calendar.getInstance();long[] ts=times(c,today);long now=System.currentTimeMillis();int next=-1;for(int i=0;i<6;i++)if(ts[i]>now){next=i;break;}long at,prev;
                if(next<0){Calendar tomorrow=(Calendar)today.clone();tomorrow.add(Calendar.DAY_OF_MONTH,1);at=times(c,tomorrow)[0];prev=ts[5];next=0;}else{at=ts[next];if(next>0)prev=ts[next-1];else{Calendar yesterday=(Calendar)today.clone();yesterday.add(Calendar.DAY_OF_MONTH,-1);prev=times(c,yesterday)[5];}}
                String[] names=ar?new String[]{"الفجر","الشروق","الظهر","العصر","المغرب","العشاء"}:new String[]{"Fajr","Sunrise","Dhuhr","Asr","Maghrib","Isha"};
                if(type==Prayers.class){float rowH=h/6f,pad=12*d;for(int i=0;i<6;i++){float cy=rowH*i+rowH/2;Paint pill=new Paint(Paint.ANTI_ALIAS_FLAG);pill.setColor(0x38FFFFFF);if(i==next)cv.drawRoundRect(new RectF(pad/2,cy-rowH/2+2*d,w-pad/2,cy+rowH/2-2*d),rowH*.42f,rowH*.42f,pill);TextPaint p=paint(medium,13,d,Color.WHITE),q=paint(bold,13,d,Color.WHITE);float baseline=cy-(p.descent()+p.ascent())/2;String t=time(ts[i],l);cv.drawText(names[i],ar?w-pad-p.measureText(names[i]):pad,baseline,p);cv.drawText(t,ar?pad:w-pad-q.measureText(t),baseline,q);}}
                else {long minutes=Math.max(0,(at-now)/60000);String countdown=minutes>=60?number(minutes/60,l)+(ar?" س ":"h ")+number(minutes%60,l)+(ar?" د":"m"):number(minutes,l)+(ar?" د":"m");lines(cv,w,(int)(h-20*d),d,new String[]{names[next],time(at,l)+" · "+countdown},new float[]{22,13},new Typeface[]{amiri,medium});Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);float left=12*d,top=h-16*d,width=w-24*d,bh=4*d;p.setColor(0x40FFFFFF);cv.drawRoundRect(new RectF(left,top,left+width,top+bh),bh/2,bh/2,p);float fraction=Math.max(0,Math.min(1,(now-prev)/(float)Math.max(1,at-prev))),fw=Math.max(bh,width*fraction);p.setColor(Color.WHITE);cv.drawRoundRect(new RectF(ar?left+width-fw:left,top,ar?left+width:left+fw,top+bh),bh/2,bh/2,p);}
            }catch(Exception ex){android.util.Log.e("WathakkerLock","Prayer bridge failed",ex);lines(cv,w,h,d,new String[]{ar?"تعذر حساب الصلاة":"Prayer time unavailable"},new float[]{13},new Typeface[]{medium});}
        }
        return bmp;
    }
}
