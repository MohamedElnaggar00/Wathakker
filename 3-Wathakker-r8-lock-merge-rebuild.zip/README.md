# Wathakker lock-widget test

This test adds the six Prayer-Sam-Widgets designs to the recovered Wathakker V3.0 r7 app. The original r7 Kotlin source and original signing key were unavailable. Existing compiled r7 code is retained without changes, and a small native Android widget module is added.

Package: `com.wathakker.locktest`. App label: `وَذكِّر - اختبار القفل`. It installs separately and does not replace the original app. Its data is separate. Set the location and calculation method inside the test app before checking prayer widgets.

Six added lock widgets: day, prayer times, tasbih, Hijri date, Gregorian date, next prayer. All twelve original Wathakker widgets remain. The new prayer widgets call Wathakker's existing calculator and preferences. Tasbih counts are per-widget. Samsung vendor metadata follows the inspected Athkar provider pattern.

Build and signature verification passed. Arabic and English bitmap rendering was checked using Robolectric with fixed prayer test data. Actual Samsung lock-picker eligibility, sizing and tap behavior still require device testing. Minute alarm updates are best-effort and can be delayed by Android power management.

The archive contains the recovered resource/bytecode build base, readable Java widget source, and a build script. It is not a restoration of the original V3.0 Kotlin source. No signing private key is included. The new signing key is stored separately and must be reused for later test updates.

Fonts: Amiri and Tajawal, SIL Open Font License, included under `recovered/assets/lockfonts/OFL.txt`.
