V3.0.4 startup ART verifier fix.
Exact shipped APK SHA256: 034a37d6d48541cb9f9443c944726a9517c380b3a96a3af4ecbaddb1bedf5944
ART error: OneUIDrawer$lambda$80$lambda$79 at 0x317, v4 Integer passed where String required.
Divider comparison overwrote live v4 String. Preserve it in v92 before comparison and restore it at common branch target. Reassembled shipped classes6.dex only. Other app DEX/resources unchanged.
Must pass real Android cold-start and same-certificate upgrade tests before delivery. No release or delivery authorization implied by this archive.
