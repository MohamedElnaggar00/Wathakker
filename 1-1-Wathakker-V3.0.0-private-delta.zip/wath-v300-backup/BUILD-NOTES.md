# Wathakker 3.0.0 private rebuild

Incremental patch over the r11 private rebuild on oneui-redesign. Not a replacement for the original r7 signing identity or data.

- Package: com.wathakker.locktest. Version code 6, version name 3.0.0.
- Application debuggable=false. Signed with the existing private locktest certificate.
- New adaptive home-widget bitmap renderer. 4x1 countdown follows the approved drawing: dates, names/countdown, bar, times. Small NextPrayer and PrayerBar adapt between 1x1 and 2x1.
- All displayed prayer clock times include ص/م in Arabic or AM/PM in English.
- Home prayer/adhan widgets open the prayer screen; date widgets open the main screen. Lock-widget taps remain inactive.
- Iqama, IqamaSmall and WideBar providers are disabled.
- Dark UI surfaces and Expo Arabic personal-use fonts. Font license not verified; no public distribution is authorized by this backup. See EXPO-FONT-NOTE.md.
- Existing lock geometry retained. Device validation remains required for Samsung host sizing, live updates and full Compose screen appearance.

Assembly: preserve unchanged original dex partitions. Compile the Java sources against Android API 36 with UTF-8, then D8 to the added dex partition. Overlay smali-patches on full original classes4/6/7/10/11 partitions and assemble using Assemble.java with API28/dex039. Overlay the included manifest/resources/fonts/assets on r11, use apktool 3.0.3, zipalign and sign privately. Signing key is deliberately excluded.

Validation: Android native graphics tests passed for Arabic and English widget rendering, prayer-time calculations, iqama windows and prayer-tab routing. APK signature v1/v2/v3 verified. No original-app install, uninstall, data migration or public release occurred.

APK SHA256: 909fc1c4d149dc898b5553789ecf075f339dbe5677638dc02c987ddb214cfbcc
