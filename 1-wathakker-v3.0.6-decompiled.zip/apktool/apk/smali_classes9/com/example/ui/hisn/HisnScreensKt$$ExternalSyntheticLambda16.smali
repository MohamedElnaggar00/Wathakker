.class public final synthetic Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/example/data/HisnChapter;

.field public final synthetic f$1:I

.field public final synthetic f$2:Z

.field public final synthetic f$3:Z

.field public final synthetic f$4:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$5:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$6:I


# direct methods
.method public synthetic constructor <init>(Lcom/example/data/HisnChapter;IZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$0:Lcom/example/data/HisnChapter;

    iput p2, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$1:I

    iput-boolean p3, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$2:Z

    iput-boolean p4, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$3:Z

    iput-object p5, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$4:Lkotlin/jvm/functions/Function0;

    iput-object p6, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$5:Lkotlin/jvm/functions/Function0;

    iput p7, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$6:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    .line 0
    iget-object v0, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$0:Lcom/example/data/HisnChapter;

    iget v1, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$1:I

    iget-boolean v2, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$2:Z

    iget-boolean v3, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$3:Z

    iget-object v4, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$4:Lkotlin/jvm/functions/Function0;

    iget-object v5, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$5:Lkotlin/jvm/functions/Function0;

    iget v6, p0, Lcom/example/ui/hisn/HisnScreensKt$$ExternalSyntheticLambda16;->f$6:I

    move-object v7, p1

    check-cast v7, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-static/range {v0 .. v8}, Lcom/example/ui/hisn/HisnScreensKt;->ChapterRow$lambda$29(Lcom/example/data/HisnChapter;IZZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
