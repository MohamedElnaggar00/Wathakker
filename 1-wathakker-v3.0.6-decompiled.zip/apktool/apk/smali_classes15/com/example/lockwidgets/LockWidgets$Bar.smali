.class public Lcom/example/lockwidgets/LockWidgets$Bar;
.super Lcom/example/lockwidgets/LockWidgets;
.source "LockWidgets.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/lockwidgets/LockWidgets;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Bar"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 23
    invoke-direct {p0}, Lcom/example/lockwidgets/LockWidgets;-><init>()V

    return-void
.end method
