.class public final synthetic Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda9;->f$0:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda9;->f$0:Landroidx/compose/runtime/MutableState;

    check-cast p1, Lcom/example/data/Tag;

    invoke-static {v0, p1}, Lcom/example/ui/screens/TagsScreenKt;->TagsScreen$lambda$19$lambda$18(Landroidx/compose/runtime/MutableState;Lcom/example/data/Tag;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
