.class public final synthetic Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/example/data/Tag;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$3:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$4:I


# direct methods
.method public synthetic constructor <init>(Lcom/example/data/Tag;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$0:Lcom/example/data/Tag;

    iput p2, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$1:I

    iput-object p3, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$2:Lkotlin/jvm/functions/Function0;

    iput-object p4, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$3:Lkotlin/jvm/functions/Function0;

    iput p5, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$4:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 0
    iget-object v0, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$0:Lcom/example/data/Tag;

    iget v1, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$1:I

    iget-object v2, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$2:Lkotlin/jvm/functions/Function0;

    iget-object v3, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$3:Lkotlin/jvm/functions/Function0;

    iget v4, p0, Lcom/example/ui/screens/TagsScreenKt$$ExternalSyntheticLambda23;->f$4:I

    move-object v5, p1

    check-cast v5, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-static/range {v0 .. v6}, Lcom/example/ui/screens/TagsScreenKt;->TagRow$lambda$51(Lcom/example/data/Tag;ILkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method
