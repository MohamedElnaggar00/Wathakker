.class public final Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;
.super Lkotlin/jvm/internal/Lambda;
.source "LazyDsl.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/ui/screens/HomeScreenKt;->AzkarListContent(Ljava/util/List;ILjava/util/List;Ljava/util/Map;Lcom/example/data/Tag;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/Lambda;",
        "Lkotlin/jvm/functions/Function4<",
        "Landroidx/compose/foundation/lazy/LazyItemScope;",
        "Ljava/lang/Integer;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLazyDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt$items$4\n+ 2 HomeScreen.kt\ncom/example/ui/screens/HomeScreenKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,433:1\n149#2,2:434\n151#2:442\n1282#3,6:436\n*S KotlinDebug\n*F\n+ 1 HomeScreen.kt\ncom/example/ui/screens/HomeScreenKt\n*L\n150#1:436,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0008\n\u0002\u0008\u0003\u0010\u0000\u001a\u00020\u0001\"\u0004\u0008\u0000\u0010\u0002*\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u000b\u00a2\u0006\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u0008"
    }
    d2 = {
        "<anonymous>",
        "",
        "T",
        "Landroidx/compose/foundation/lazy/LazyItemScope;",
        "it",
        "",
        "invoke",
        "(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V",
        "androidx/compose/foundation/lazy/LazyDslKt$items$4"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $items:Ljava/util/List;

.field final synthetic $onSelectTag$inlined:Lkotlin/jvm/functions/Function1;

.field final synthetic $selectedTag$inlined:Lcom/example/data/Tag;


# direct methods
.method public constructor <init>(Ljava/util/List;Lcom/example/data/Tag;Lkotlin/jvm/functions/Function1;)V
    .locals 0

    iput-object p1, p0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$items:Ljava/util/List;

    iput-object p2, p0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$selectedTag$inlined:Lcom/example/data/Tag;

    iput-object p3, p0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$onSelectTag$inlined:Lkotlin/jvm/functions/Function1;

    const/4 p2, 0x4

    invoke-direct {p0, p2}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;
    .param p4, "p4"    # Ljava/lang/Object;

    .line 152
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/lazy/LazyItemScope;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    move-object v2, p3

    check-cast v2, Landroidx/compose/runtime/Composer;

    move-object v3, p4

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    invoke-virtual {p0, v0, v1, v2, v3}, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V
    .locals 19
    .param p1, "$this$items"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "it"    # I
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move/from16 v1, p2

    move-object/from16 v2, p3

    const-string v3, "C152@7074L22:LazyDsl.kt#428nma"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p4

    .local v3, "$dirty":I
    and-int/lit8 v4, p4, 0x6

    if-nez v4, :cond_1

    move-object/from16 v4, p1

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    :goto_0
    or-int/2addr v3, v6

    goto :goto_1

    :cond_1
    move-object/from16 v4, p1

    :goto_1
    and-int/lit8 v6, p4, 0x30

    const/16 v7, 0x20

    if-nez v6, :cond_3

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v6

    if-eqz v6, :cond_2

    move v6, v7

    goto :goto_2

    :cond_2
    const/16 v6, 0x10

    :goto_2
    or-int/2addr v3, v6

    .line 153
    :cond_3
    and-int/lit16 v6, v3, 0x93

    const/16 v8, 0x92

    if-ne v6, v8, :cond_5

    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getSkipping()Z

    move-result v6

    if-nez v6, :cond_4

    goto :goto_3

    :cond_4
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v5, v3

    goto/16 :goto_7

    :cond_5
    :goto_3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_6

    const/4 v6, -0x1

    const-string v8, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:152)"

    const v9, -0x25b7f321

    invoke-static {v9, v3, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_6
    iget-object v6, v0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$items:Ljava/util/List;

    invoke-interface {v6, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    and-int/lit8 v8, v3, 0xe

    .local v8, "$changed\\1":I
    check-cast v6, Lcom/example/data/Tag;

    .local v6, "tag\\1":Lcom/example/data/Tag;
    move-object/from16 v9, p1

    .local v9, "$this$AzkarListContent_u24lambda_u2449_u24lambda_u2448_u24lambda_u2446_u24lambda_u2445_u24lambda_u2444_u24lambda_u2443\\1":Landroidx/compose/foundation/lazy/LazyItemScope;
    move-object/from16 v15, p3

    .local v15, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 434
    .local v18, "$i$a$-items$default-HomeScreenKt$AzkarListContent$2$1$2$1$1$3\\1\\153\\0":I
    const v10, -0x52f935a9

    invoke-interface {v15, v10}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v10, "CN(tag)*149@5666L39,149@5641L101:HomeScreen.kt#2thlc2"

    invoke-static {v15, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    iget-object v10, v0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$selectedTag$inlined:Lcom/example/data/Tag;

    const/4 v12, 0x0

    if-eqz v10, :cond_7

    iget-object v10, v0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$selectedTag$inlined:Lcom/example/data/Tag;

    invoke-virtual {v10}, Lcom/example/data/Tag;->getTagId()J

    move-result-wide v13

    invoke-virtual {v6}, Lcom/example/data/Tag;->getTagId()J

    move-result-wide v16

    cmp-long v10, v13, v16

    if-nez v10, :cond_7

    const/4 v10, 0x1

    goto :goto_4

    :cond_7
    move v10, v12

    .line 435
    .local v10, "sel\\1":Z
    :goto_4
    invoke-virtual {v6}, Lcom/example/data/Tag;->getName()Ljava/lang/String;

    move-result-object v13

    const v14, -0x1b7359f4

    const-string v11, "CC(remember):HomeScreen.kt#9igjgp"

    invoke-static {v15, v14, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    iget-object v11, v0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$onSelectTag$inlined:Lkotlin/jvm/functions/Function1;

    invoke-interface {v15, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v11

    invoke-interface {v15, v10}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v14

    or-int/2addr v11, v14

    and-int/lit8 v14, v8, 0x70

    xor-int/lit8 v14, v14, 0x30

    if-le v14, v7, :cond_8

    invoke-interface {v15, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_9

    :cond_8
    and-int/lit8 v14, v8, 0x30

    if-ne v14, v7, :cond_a

    :cond_9
    const/4 v12, 0x1

    :cond_a
    or-int v7, v11, v12

    .local v7, "invalid\\2":Z
    move-object v11, v15

    .local v11, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 436
    .local v12, "$i$f$cache\\2\\435":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\2":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 437
    .local v16, "$i$a$-let-ComposerKt$cache$1\\3\\436\\2":I
    if-nez v7, :cond_c

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v14, v5, :cond_b

    goto :goto_5

    .line 441
    :cond_b
    goto :goto_6

    .line 438
    :cond_c
    :goto_5
    const/4 v5, 0x0

    .line 435
    .local v5, "$i$a$-cache-HomeScreenKt$AzkarListContent$2$1$2$1$1$3$1\\4\\438\\1":I
    new-instance v1, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$2$1$2$1$1$3$1$1;

    iget-object v2, v0, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$lambda$49$lambda$48$lambda$46$lambda$45$lambda$44$$inlined$items$default$4;->$onSelectTag$inlined:Lkotlin/jvm/functions/Function1;

    invoke-direct {v1, v2, v10, v6}, Lcom/example/ui/screens/HomeScreenKt$AzkarListContent$2$1$2$1$1$3$1$1;-><init>(Lkotlin/jvm/functions/Function1;ZLcom/example/data/Tag;)V

    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 438
    .end local v5    # "$i$a$-cache-HomeScreenKt$AzkarListContent$2$1$2$1$1$3$1\\4\\438\\1":I
    nop

    .line 439
    .local v1, "value\\3":Ljava/lang/Object;
    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 440
    move-object v14, v1

    .line 436
    .end local v1    # "value\\3":Ljava/lang/Object;
    .end local v14    # "it\\2":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\3\\436\\2":I
    :goto_6
    nop

    .line 435
    .end local v7    # "invalid\\2":Z
    .end local v11    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\2\\435":I
    move-object v12, v14

    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual {v6}, Lcom/example/data/Tag;->getColorHex()Ljava/lang/String;

    move-result-object v1

    move v5, v3

    .end local v3    # "$dirty":I
    .local v5, "$dirty":I
    const-wide/16 v2, 0x0

    const/4 v7, 0x0

    const/4 v11, 0x2

    invoke-static {v1, v2, v3, v11, v7}, Lcom/example/ui/oneui/OneUIKt;->parseColorSafe-4WTKRHQ$default(Ljava/lang/String;JILjava/lang/Object;)J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/Color;->box-impl(J)Landroidx/compose/ui/graphics/Color;

    move-result-object v14

    const/16 v16, 0x0

    const/16 v17, 0x8

    move v11, v10

    move-object v10, v13

    .end local v10    # "sel\\1":Z
    .local v11, "sel\\1":Z
    const/4 v13, 0x0

    invoke-static/range {v10 .. v17}, Lcom/example/ui/oneui/OneUIKt;->OneUIChip-M8YrEPQ(Ljava/lang/String;ZLkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Color;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 442
    .end local v11    # "sel\\1":Z
    nop

    .line 153
    .end local v6    # "tag\\1":Lcom/example/data/Tag;
    .end local v8    # "$changed\\1":I
    .end local v9    # "$this$AzkarListContent_u24lambda_u2449_u24lambda_u2448_u24lambda_u2446_u24lambda_u2445_u24lambda_u2444_u24lambda_u2443\\1":Landroidx/compose/foundation/lazy/LazyItemScope;
    .end local v15    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-items$default-HomeScreenKt$AzkarListContent$2$1$2$1$1$3\\1\\153\\0":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 154
    :cond_d
    :goto_7
    return-void
.end method
