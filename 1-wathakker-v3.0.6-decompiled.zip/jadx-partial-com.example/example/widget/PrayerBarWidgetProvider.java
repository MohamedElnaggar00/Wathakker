package com.example.widget;

import kotlin.Metadata;

/* compiled from: WidgetProviders.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/example/widget/PrayerBarWidgetProvider;", "Lcom/example/widget/BaseWathakkerWidgetProvider;", "<init>", "()V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* loaded from: classes10.dex */
public final class PrayerBarWidgetProvider extends BaseWathakkerWidgetProvider {
    public static final int $stable = 8;
}
