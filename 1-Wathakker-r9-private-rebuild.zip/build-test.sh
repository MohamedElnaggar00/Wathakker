#!/usr/bin/env bash
set -euo pipefail
# Set TOOLCHAIN to Android build-tools + android.jar, APKTOOL to apktool.jar, JAVA_HOME to JDK 17.
: "${TOOLCHAIN:?}" "${APKTOOL:?}" "${JAVA_HOME:?}" "${SIGNING_KEY:?}"
"$JAVA_HOME/bin/javac" -encoding UTF-8 -source 8 -target 8 -cp "$TOOLCHAIN/android.jar" -d classes src/com/example/lockwidgets/LockWidgets.java
mkdir -p dex
"$JAVA_HOME/bin/java" -cp "$TOOLCHAIN/lib/d8.jar" com.android.tools.r8.D8 --min-api 26 --lib "$TOOLCHAIN/android.jar" --output dex $(find classes -name '*.class')
cp dex/classes.dex recovered/classes15.dex
java -jar "$APKTOOL" b recovered -o unsigned.apk
"$TOOLCHAIN/zipalign" -f -p 4 unsigned.apk aligned.apk
"$TOOLCHAIN/apksigner" sign --ks "$SIGNING_KEY" --ks-pass pass:android --key-pass pass:android --ks-key-alias locktest --out Wathakker-locktest-r8.apk aligned.apk
"$TOOLCHAIN/apksigner" verify Wathakker-locktest-r8.apk
