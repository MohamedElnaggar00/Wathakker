# Wathakker r9 personal lock-widget test

Private build, not for publication. Based on recovered Wathakker V3.0 r7 APK resources and unchanged compiled code, with a source-backed native widget module in classes15.dex. The original V3.0 Kotlin source and signing key are not restored.

Package `com.wathakker.locktest`, app label `وَذكِّر - اختبار القفل`. Same test signing key as r8. This updates the separate test app and leaves the original installed r7 and its data alone. Configure prayer location and calculation method in the test app.

Seven added lock widgets: day, horizontal prayer schedule, tasbih, Hijri date, Gregorian date, next prayer, prayer progress strip. All twelve original widgets remain. Small slots render at 123x54 dp; date/next widgets also adapt to 54x54 tiny slots. Prayer settings/calculation use r7's existing classes.

Includes user-requested personal reference fonts and day/month artwork extracted from the user-supplied Athkar APK. These assets are not open-source and are not offered under the repository's code license. Do not publish this archive, APK or assets. Keep the repository private. Original font copyright notices are retained in font metadata. Amiri/Tajawal OFL license remains included for the independent assets.

Verified: APK resource build and signing, original bytecode hashes, rendered Arabic/English small/tiny images with fixed prayer test data. Samsung picker eligibility was confirmed on the r8 test by the owner. r9 visuals, actual host-size selection, prayer bridge and tasbih taps need device review. Minute refresh alarms are best-effort under Android power management.

No signing key in this archive; it is stored separately and must be reused. No release or main-branch merge was made. Build script expects JDK17, apktool 3.0.3, Android 36 android.jar/build-tools and the test signing key. The source archive is a rebuild base, not a Gradle restoration of r7.
