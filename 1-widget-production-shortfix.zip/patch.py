from pathlib import Path
import xml.etree.ElementTree as E,shutil
p=Path('decoded');ns='{http://schemas.android.com/apk/res/android}'
f=p/'AndroidManifest.xml';tree=E.parse(f);r=tree.getroot();r.set(ns+'versionCode','12');r.set(ns+'versionName','3.0.6');app=r.find('application');old=next(x for x in app.findall('receiver') if x.get(ns+'name')=='com.example.widget.HeroWidgetProvider');old.set(ns+'label','تقدم الصلاة 4×1');new=E.fromstring(E.tostring(old));new.set(ns+'name','com.example.widget.HeroLargeWidgetProvider');new.set(ns+'label','تقدم الصلاة 4×2');new.find('meta-data').set(ns+'resource','@xml/widget_hero_large_info');app.append(new);E.register_namespace('android','http://schemas.android.com/apk/res/android');tree.write(f,encoding='utf-8',xml_declaration=True)
for src in Path('patch/res').rglob('*'):
 if src.is_file():dst=p/'res'/src.relative_to('patch/res');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy(src,dst)
f=p/'apktool.yml';s=f.read_text().replace("versionCode: 11","versionCode: 12").replace("versionName: 3.0.5","versionName: 3.0.6");f.write_text(s)
